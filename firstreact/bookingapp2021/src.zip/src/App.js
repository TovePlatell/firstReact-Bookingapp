
import './App.css';
import AppRoute from "./components/AppRoute"

function App() {
  return (
    <div className="App">

      <AppRoute />
      
    </div>
  );
}

// parent element

export default App;