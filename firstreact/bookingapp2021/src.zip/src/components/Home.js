import React from "react";
import { Link } from "react-router-dom";

// ska jag göra en navbar på nedan istället och ha HOME med bakgrundsbild sen länkar upptill istället

// varför funkar inte space between mellan länkarna uppe i headern

function Home() {
  return (    
    <div className="bg-red-600 flex justify-around">
          <Link
            to="/"
            Home
            className="inline-flex items-center py-6 px-3 mr-4 text-red-100 hover:text-green-800 text-4xl font-bold tracking-widest"
          ></Link>

          <Link
            to="/Cardlist"
            className="inline-flex items-center py-3 my-6 rounded text-red-200 hover:text-green-800"
          >
            {" "}
            Our offices{" "}
          </Link>

          <Link
            to="/Home"
            className="inline-flex items-center py-3 my-6 rounded text-red-200 hover:text-green-800"
          >
            {" "}
            About us{" "}
          </Link>

          <button>
            <i
              class="material-icons"
              className="inline-flex items-center py-3 my-6 rounded text-red-200 hover:text-green-800"
            >
              Login{" "}
            </i>
          </button>
    </div>
  );
}

// istället för a tag har man link -

export default Home;
