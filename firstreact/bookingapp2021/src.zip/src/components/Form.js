import React, {useState} from 'react'


function Form() {


    const initialValues = {
        officeName:" ",
        location: " ",
        price: " "
    }
    const [formValues, setFormValues] = useState(initialValues)


    function onHandleSubmit(e) {
      // ska skickas till db eller api endpoint
      console.log(formValues)
      e.preventDefault();


    }
  
// vi sätter setFormValues utefter inputen - sparas i formvalues
// e.target.name = tar value från inputen ... måste ha tre punkter för att ta gamla värdet//extrahera 
//e.target.value 

    function onHandleChange(e) {

      setFormValues( {
        ...formValues,
        [e.target.name]:e.target.value

        
        // fixa detta 
    })


  }
    return (
        <>
            
      
      <form onSubmit={onHandleSubmit} >
            <label> Search for Office:  </label> 
            
            <input className="border" placeholder="Choose your location" value={formValues.productName} name="productName" onChange={onHandleChange} />

            <input className="border " placeholder="Max price" type="number" name="price" value ={formValues.price} onChange={onHandleChange}/>

            <button className="bg-purple-600">Search</button>
       </form>
        
        
        </>
    )
}

export default Form