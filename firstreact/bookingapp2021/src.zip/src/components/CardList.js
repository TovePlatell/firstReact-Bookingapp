import React from "react";
import Card from "./Card";

// ska komma från database eller apies
const officeList = [
  {
    officeName: "Room1",
    image: "./images/office1.jpg",
    location: "Location: unknown",
    price: "25.000 per month",
  },
  {
    officeName: "Room2",
    image: "./images/office2.jpg",
    location: "Address: unknown",
    price: "10.000 per month",
  },
  {
    officeName: "Room3",
    image: "./images/office3.jpg",
    location: "Location: unknown",
    price: "5.000 per month",
  },
];

// (product)=> {return (<Card />)}
// visar lista över alla produkter
function CardList() {
  return (
    <div>
      {officeList.map((office) => {
        return(
          <Card
            officeName={office.officeName}
            okej={office.image} 
        
            location={office.location}
            price={office.price}
          />
      )
      })}
    </div>
  );
}

export default CardList;

// rfce
