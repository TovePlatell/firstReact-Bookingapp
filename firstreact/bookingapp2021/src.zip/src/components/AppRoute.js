import React from "react";
import CardList from "./CardList";
import Form from "./Form";
import Home from "./Home";

import { Route, BrowserRouter as Router, Switch } from "react-router-dom";
// react-router-dom ??

// yarn add react-router-dom

// olika router

export default function AppRoute() {
  return (
      <Router>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/cardlist" component={CardList} />
          <Route exact path="/form" component={Form} />
        </Switch>
      </Router>
  );
}
