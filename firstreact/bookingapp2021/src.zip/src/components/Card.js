import React from 'react'

// detta är en card mall 
//parent till cardlist


function card({officeName, okej, location, price}) {
    return (
        <div className="relative bg-white">
            
        ============================================   
           <div>  {officeName}   </div> 
           <img src={okej} alt="" />
            <div>  Location:  {location} </div>
            <div>  Pris:  {price} </div>
        ============================================
        </div>
    )
}

export default card